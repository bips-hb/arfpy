import setuptools

setuptools.setup(
    name="arfpy",
    version = "0.0.1",
    author= "blesch kapar wright",
    description="Adversarial random forests for density estimation and generative modeling",
    packages=['arfpy']
)
# arfpy

This is a python implementation of adversarial random forests for density estimation and generative modelling

Accompanying paper by David Watson, Kristin Blesch, Jan Kapar and Marvin N. Wright (2023) https://arxiv.org/abs/2205.09435

R implementation available on CRAN https://cran.r-project.org/web/packages/arf/index.html